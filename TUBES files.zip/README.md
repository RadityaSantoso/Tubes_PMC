# Tubes_PMC
Raditya Anggara N. Santoso
Mohammad Adam Febrian
Dennis Hubert
Fitraka Ario Sutansyah
Requint Nurliawan


## Pemakaian Program:
### C tanpa GUI
Export/clone seluruh repo ke salah satu folder dan run main.c
Program akan berjalan
### GUI
Export folder GUI ke salah satu folder dan run exe
